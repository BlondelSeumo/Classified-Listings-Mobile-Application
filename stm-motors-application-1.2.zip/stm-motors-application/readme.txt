=== Motors Application ===
Contributors: StylemixThemes
Donate link: https://stylemixthemes.com/
Tags: gdpr, cookie consent, gdpr compliance, privacy policy
Requires at least: 4.6
Tested up to: 5.2
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html