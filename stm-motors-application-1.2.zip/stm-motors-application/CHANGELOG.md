## 1.2
- **FIX:** Seller note editor add html tag support.