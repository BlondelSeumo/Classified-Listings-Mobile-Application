(function($) {
    $(document).ready(function() {
        //$('#stmMATabs li:nth-child(1) a').tab('show');

        $('input[name="ad_type"]').on('change', function () {
            $('.banner-ids-wrap').removeClass('visible');
            $('.interstitial-ids-wrap').removeClass('visible');

            if($(this).val() == 'banner') {
                $('.banner-ids-wrap').addClass('visible');
            } else {
                $('.interstitial-ids-wrap').addClass('visible');
            }
        });

        $('input[name="stm-ma-str-placeholder"]').on('change', function () {
            var key = $(this).attr('data-key');
            $('input[data-key="hidden-' + key + '"]').val($(this).val());
        })

        $('input[name="grid_view"]').on('change', function() {
            $('.radio-wrap').removeClass('grid-checked');
            $(this).parent().parent().addClass('grid-checked');
        });

        $('input[name="main_color"]').wpColorPicker({
            defaultColor: '#1bc744',
            change: function(event, ui){ },
            clear: function(){ },
            hide: true,
            palettes: false
        });

        $('input[name="second_color"]').wpColorPicker({
            defaultColor: '#2d60f3',
            change: function(event, ui){ },
            clear: function(){ },
            hide: true,
            palettes: false
        });

        $('#filter-select').multiSelect({
            keepOrder: true,
            afterSelect: function (val) {
                var get_val = $('input[name="filter-opt"]').val();
                var hidden_val = (get_val != "") ? get_val+"," : get_val;

                $('input[name="filter-opt"]').val(hidden_val+""+val);
            },
            afterDeselect: function (val) {
                var get_val = $('input[name="filter-opt"]').val();
                var new_val = get_val.replace(val + ',', "");
                new_val = new_val.replace(val, "");

                $('input[name="filter-opt"]').val(new_val);
            }
        });

        $('#step_one-select').multiSelect({
            keepOrder: true,
            afterSelect: function (val) {
                var get_val = $('input[name="step_one-opt"]').val();
                var hidden_val = (get_val != "") ? get_val+"," : get_val;

                $('input[name="step_one-opt"]').val(hidden_val+""+val);
            },
            afterDeselect: function (val) {
                var get_val = $('input[name="step_one-opt"]').val();
                var new_val = get_val.replace(val + ',', "");
                new_val = new_val.replace(val, "");

                $('input[name="step_one-opt"]').val(new_val);

            }
        });

        $('#step_two-select').multiSelect({
            keepOrder: true,
            afterSelect: function (val) {
                var get_val = $('input[name="step_two-opt"]').val();
                var hidden_val = (get_val != "") ? get_val+"," : get_val;

                $('input[name="step_two-opt"]').val(hidden_val+""+val);
            },
            afterDeselect: function (val) {
                var get_val = $('input[name="step_two-opt"]').val();
                var new_val = get_val.replace(val + ',', "");
                new_val = new_val.replace(val, "");

                $('input[name="step_two-opt"]').val(new_val);
            }
        });

        $('#step_three-select').multiSelect({
            keepOrder: true,
            afterSelect: function (val) {
                var get_val = $('input[name="step_three-opt"]').val();
                var hidden_val = (get_val != "") ? get_val+"," : get_val;

                $('input[name="step_three-opt"]').val(hidden_val+""+val);
            },
            afterDeselect: function (val) {
                var get_val = $('input[name="step_three-opt"]').val();
                var new_val = get_val.replace(val + ',', "");
                new_val = new_val.replace(val, "");

                $('input[name="step_three-opt"]').val(new_val);
            }
        });

        if(filterParams.length > 0) {
            filterParams.forEach(function(item, i, filterParams) {
                $('#filter-select').multiSelect('select', item);
            });
        }

        if(stepOne.length > 0) {
            stepOne.forEach(function(item, i, stepOne) {
                $('#step_one-select').multiSelect('select', item);
            });
        }
        if(stepTwo.length > 0) {
            stepTwo.forEach(function(item, i, stepTwo) {
                $('#step_two-select').multiSelect('select', item);
            });
        }
        if(stepThree.length > 0) {
            stepThree.forEach(function(item, i, stepThree) {
                $('#step_three-select').multiSelect('select', item);
            });
        }
    });
})(jQuery);