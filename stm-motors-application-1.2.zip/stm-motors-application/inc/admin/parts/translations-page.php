<?php
$file   = file_get_contents(STM_MOTORS_APP_INC_PATH . 'translations/translations.xml');
$xml    =  simplexml_load_string($file);

$translations = get_option('translations', '');
?>

<div class="stm-translations-page-wrap">
    <h3>Translations</h3>
    <div class="translation-form">
        <table>
            <?php
                foreach ($xml as $k => $val) : if(empty($val->Key)) continue;
                $k = trim((String) $val->Key);
                $str = (!empty($translations[$k])) ? $translations[$k] : $val->Value;
            ?>
            <tr>
                <td><?php echo esc_html($val->Value); ?></td>
                <td>
                    <input type="text" data-key="<?php echo esc_attr($val->Key); ?>" name="stm-ma-str-placeholder" value="<?php echo esc_attr($str); ?>" />
                    <input type="hidden" data-key="hidden-<?php echo esc_attr($val->Key); ?>" name="strings[<?php echo esc_attr($val->Key); ?>]" value="<?php echo esc_attr($str); ?>" />
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>
